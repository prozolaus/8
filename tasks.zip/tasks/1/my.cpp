#include "my.h"
#include "std_lib_facilities.h"

int foo = 0;

void print_foo() {
    cout << foo << endl;
}

void print(int i) {
    cout << i << endl;
}