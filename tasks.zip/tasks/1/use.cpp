#include "my.h"

int main()
{
    foo = 8;
    print_foo();
    print(99);
}