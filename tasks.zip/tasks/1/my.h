extern int foo;
void print_foo();
void print(int);