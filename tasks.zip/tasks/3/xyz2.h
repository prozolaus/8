#include <iostream>
using namespace std;

namespace X
{
    int var = 0;
    void print()
    {
        cout << var << endl;
    }
}

namespace Y
{
    int var = 0;
    void print()
    {
        cout << var << endl;
    }
}

namespace Z
{
    int var = 0;
    void print()
    {
        cout << var << endl;
    }
}